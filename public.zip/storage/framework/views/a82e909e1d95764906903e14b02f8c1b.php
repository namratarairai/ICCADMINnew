
<!doctype html>
<html lang="en">

<head>
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title', __('Not Found')); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Iconic Bootstrap 4.5.0 Admin Template">
    <meta name="author" content="WrapTheme, design by: ThemeMakker.com">

    <link rel="icon" href="<?php echo e(asset('assets/dist/favicon-32x32.png')); ?>" type="image/x-icon">
    <!-- VENDOR CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/toastr/toastr.min.css')); ?>">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
</head>

<body data-theme="light" class="font-nunito">

    <div id="wrapper" class="theme-cyan">
        <!-- Page Loader -->
        <div class="page-loader-wrapper">
            <div class="loader">
                <div class="m-t-30">
                    <img src="https://greenurjaandenergyefficiencyawards.indianchamber.org/wp-content/themes/icc_green_urja/icc_green_urja/assets/images/logo.svg"
                         width="200" height="200" alt="Iconic">
                </div>
                <p>Please wait...</p>
            </div>
        </div>

        <!-- Vertical alignment -->
        <div class="vertical-align-wrap">
            <div class="vertical-align-middle maintenance">
                <div class="text-center">
                    <article>
                        <h1><?php echo $__env->yieldContent('code', '404'); ?> - <?php echo $__env->yieldContent('title', __('Not Found')); ?><br/></h1>
                        <div>
                            <p><?php echo $__env->yieldContent('message', __('The page you are looking for could not be found. Please check the URL or return to the homepage.')); ?></p>
                        </div>
                    </article>
                    <div class="margin-top-30">
                        <a href="javascript:history.go(-1)" class="btn btn-default"><i class="fa fa-arrow-left"></i> <span>Go Back</span></a>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-info"><i class="fa fa-home"></i> <span>Home</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
    <script src="<?php echo e(asset('assets/bundles/libscripts.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bundles/vendorscripts.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\testenv\resources\views/errors/404.blade.php ENDPATH**/ ?>