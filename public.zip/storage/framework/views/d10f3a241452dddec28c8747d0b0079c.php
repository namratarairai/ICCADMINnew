<?php $__env->startSection('content'); ?>
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30"><img
                    src="https://greenurjaandenergyefficiencyawards.indianchamber.org/wp-content/themes/icc_green_urja/icc_green_urja/assets/images/logo.svg"
                    width="200" height="200" alt="Iconic"></div>
            <p>Please wait...</p>
        </div>
    </div>
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h2>Dashboard</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i
                                    class="fa fa-dashboard"></i></a></li>
                        <li class="breadcrumb-item">Dashboard</li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ul>
                </div>

            </div>
        </div>

        


    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('externaljs'); ?>
    <script src="<?php echo e(asset('assets/js/index7.js')); ?>"></script>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\iccadmin\resources\views/admin/admindashboard.blade.php ENDPATH**/ ?>