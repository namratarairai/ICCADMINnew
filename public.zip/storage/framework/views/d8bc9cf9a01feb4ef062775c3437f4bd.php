<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <div class="container-fluid">

        <div class="row clearfix pt-5">
            <div class="col-12 pb-2">
                <div class="row align-items-center text-center">
                    <img class="logo logo-light m-auto" src="https://greenurjaandenergyefficiencyawards.indianchamber.org/wp-content/themes/icc_green_urja/icc_green_urja/assets/images/logo.svg" alt="logo-dark"
                        style="width:200px;">
                </div>
            </div>
        </div>
        <!-- end page title -->
        <div class="row clearfix pt-2">
            <div class="col-lg-3"></div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12 text-center">
                                <h2 class="card-title font-weight-bold fs-4">Change Password</h2>

                            </div>
                        </div>
                        <form action="<?php echo e(route('admin.changePassworddata')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row">

        <div class="col-sm-12">
            <label>Current Password *</label>
            <div class="input-group">
                <input class="form-control" type="password" name="current-password" id="current-password" value="<?php echo e(old('current-password')); ?>">
                <div class="input-group-append">
                    <span class="input-group-text">
                        <i class="fa fa-eye-slash" id="toggleCurrentPassword" style="cursor: pointer;"></i>
                    </span>
                </div>
            </div>
            <?php $__errorArgs = ['current-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-sm-12">
            <label>New Password *</label>
            <div class="input-group">
                <input class="form-control" type="password" name="new-password" id="new-password" value="<?php echo e(old('new-password')); ?>">
                <div class="input-group-append">
                    <span class="input-group-text">
                        <i class="fa fa-eye-slash" id="toggleNewPassword" style="cursor: pointer;"></i>
                    </span>
                </div>
            </div>
            <?php $__errorArgs = ['new-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-sm-12">
            <label>Confirm Password *</label>
            <div class="input-group">
                <input class="form-control" type="password" name="password_confirmation" id="confirm-password" value="<?php echo e(old('password_confirmation')); ?>">
                <div class="input-group-append">
                    <span class="input-group-text">
                        <i class="fa fa-eye-slash" id="toggleConfirmPassword" style="cursor: pointer;"></i>
                    </span>
                </div>
            </div>
            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>

    <div class="row">
        <div class="col-md-12">
            <button class="mt-3 btn btn-primary p-2 form-btn" id="videoBtn">SAVE <i class="fa fa-spin fa-spinner" id="videoSpin" style="display:none;"></i></button>
            <button class="mt-3 btn btn-danger p-2 form-btn"><a class="text-white" href="">Cancel</a></button>
        </div>
    </div>
</form>


                    </div>
                </div>
            </div>
            <div class="col-lg-3"></div>
        </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('externaljs'); ?>
    <script src="<?php echo e(asset('assets/js/pages/profile.js')); ?>"></script>
    <script>
    document.getElementById('toggleCurrentPassword').addEventListener('click', function() {
        var passwordField = document.getElementById('current-password');
        var icon = this;
        togglePasswordVisibility(passwordField, icon);
    });

    document.getElementById('toggleNewPassword').addEventListener('click', function() {
        var passwordField = document.getElementById('new-password');
        var icon = this;
        togglePasswordVisibility(passwordField, icon);
    });

    document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
        var passwordField = document.getElementById('confirm-password');
        var icon = this;
        togglePasswordVisibility(passwordField, icon);
    });

    function togglePasswordVisibility(passwordField, icon) {
        if (passwordField.type === "password") {
            passwordField.type = "text";
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        } else {
            passwordField.type = "password";
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\testenv\resources\views/admin/change-password.blade.php ENDPATH**/ ?>