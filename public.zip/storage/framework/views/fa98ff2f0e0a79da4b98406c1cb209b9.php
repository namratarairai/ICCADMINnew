<?php $__env->startSection('content'); ?>
    

 <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h2>Document List</h2>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('document-add')): ?>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="d-flex flex-row-reverse">
                            <div class="page_action">
                                <a href="<?php echo e(route('admin.adddocumentshow')); ?>" type="button" class="btn btn-secondary">Add
                                    new</a>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!--Add / Edit Form -->
        

        <!---Document List -->
        
    </div>
        <!---card doc list-->
        <div class="container-fluid file_manager">
            <div class="block-header">
                <div class="row">
                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $encryptedId = encrypt($document->id);
                            $fileExtension = pathinfo($document->document, PATHINFO_EXTENSION);
                        ?>
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <div class="card">
                                <div class="file">
                                    <a href="javascript:void(0);">
                                        <div class="hover">
                                            <a href="<?php echo e(asset('storage/' . $document->document)); ?>"
                                                class="btn btn-icon btn-success text-white btn-sm" download>
                                                <i class="fa fa-download fs-xsm"></i>
                                            </a>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('document-delete')): ?>
                                            <a href="javascript:void(0)"
                                                onclick="deleteData('id', <?php echo e($document->id); ?>, '<?php echo e($tablename); ?>')"
                                                class="btn btn-icon btn-danger text-white btn-sm">
                                                <i class="fa fa-trash fs-xsm"></i>
                                            </a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('document-edit')): ?>
                                            <a href="<?php echo e(route('admin.editdocument', ['id' => $encryptedId])); ?>"
                                                class="btn btn-icon btn-secondary text-white btn-sm">
                                                <i class="fa fa-edit fs-xsm"></i>
                                            </a>
                                            <?php endif; ?>

                                        </div>
                                        <div class="icon">
                                            <?php if(in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                                <div class="image-popup d-block" data-toggle="modal"
                                                    data-target="#imageModal"
                                                    data-image="<?php echo e(asset('storage/' . $document->document)); ?>">
                                                    <i class="fa fa-image text-warning d-block"></i>
                                                </div>
                                            <?php elseif($fileExtension === 'pdf'): ?>
                                                <div class="pdf-popup d-block" data-toggle="modal" data-target="#pdfModal"
                                                    data-pdf="<?php echo e(asset('storage/' . $document->document)); ?>">
                                                    <i class="fa fa-file-pdf-o text-success  d-block"></i>
                                                </div>
                                            <?php elseif(in_array($fileExtension, ['doc', 'docx'])): ?>
                                                
                                                <i class="fa fa-file-word-o text-info"></i>
                                                
                                            <?php elseif(in_array($fileExtension, ['xls', 'xlsx'])): ?>
                                                
                                                <i class="fa fa-file-excel-o text-danger"></i>
                                                
                                            <?php else: ?>
                                                <i class="fa fa-file text-muted"></i>
                                                <!-- Default icon for unknown types -->
                                            <?php endif; ?>
                                        </div>

                                        <div class="file-name">
                                            <span data-toggle="tooltip" data-placement="top" title="<?php echo e($document->title); ?>">
                                                <?php echo Str::limit(strip_tags($document->title), 30); ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('document-edit')): ?>
                                                <span class="date text-muted float-right">
                                                    <a style="vertical-align: middle;">
                                                        <!-- Toggle Switch -->
                                                        <label class="toggle-switch">
                                                            <input type="checkbox"
                                                                <?php echo e($document->status == 1 ? 'checked' : ''); ?>

                                                                onchange="changeStatus('id', '<?php echo e($document->id); ?>', 'status', '<?php echo e($document->status == 1 ? 0 : 1); ?>', '<?php echo e($tablename); ?>')">
                                                            <span class="toggle-switch-slider"></span>
                                                        </label>
                                                    </a>
                                                </span>
                                               <?php endif; ?>
                                            </span>
                                        </div>

                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

        </div>

    <!---Delet Model--->
    <div class="modal fade" id="delete_modal" tabindex="-1" aria-labelledby="delete_modal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body text-center pt-4">
                    <h3>Delete Data</h3>
                    <p>Are you sure want to delete?</p>
                    <div class="mb-3">
                        <form action="<?php echo e(route('admin.DeleteData')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="Id" id="delId" />
                            <input type="hidden" name="column" id="delColumn" />
                            <input type="hidden" name="table" id="delTable" />
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancle</button>
                            <button type="submit" class="btn btn-danger">Yes, delete it!</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap 4 Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">Image Preview</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <img id="modalImage" src="" alt="Image" class="img-fluid">
                </div>
            </div>
        </div>
    </div>

    <!-- PDF Modal -->
    <div class="modal fade" id="pdfModal" tabindex="-1" role="dialog" aria-labelledby="pdfModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="pdfModalLabel">PDF Viewer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <iframe id="pdfViewer" src="" width="100%" height="500px"></iframe>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('externaljs'); ?>
    <script type="text/javascript">
        $(document).ready(function() {

            // Form validation
            $('#addForm').validate({
                ignore: '',
                rules: {
                    title: {
                        required: true
                    },
                    category_id: {
                        required: true
                    },
                    // startdate: {
                    //     required: true,
                    //     date: true
                    // },
                    // enddate: {
                    //     required: true,
                    //     date: true
                    // },
                    document: {
                        required: true
                    },
                    // description: {
                    //     required: true
                    // }
                },
                messages: {
                    title: {
                        required: "Please enter the document title"
                    },
                    // category_id: {
                    //     required: "Please select a category"
                    // },
                    // startdate: {
                    //     required: "Please select the start date",
                    //     date: "Please enter a valid date"
                    // },
                    enddate: {
                        required: "Please select the end date",
                        date: "Please enter a valid date"
                    },
                    document: {
                        required: "Please upload the document"
                    },
                    // description: {
                    //     required: "Please enter the description"
                    // }
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('text-danger');
                    if (element.attr("name") == "category_id") {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                },
                highlight: function(element) {
                    $(element).addClass('is-invalid mb-1');
                },
                unhighlight: function(element) {
                    $(element).removeClass('is-invalid mb-1');
                }
            });


        });
    </script>
    <!-- DataTables Buttons JS -->
    <script src="https://cdn.datatables.net/buttons/2.1.0/js/dataTables.buttons.min.js"></script>
    <!-- JSZip for Excel export -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.7.1/jszip.min.js"></script>
    <!-- pdfmake for PDF export -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <!-- DataTables Buttons HTML5 export -->
    <script src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.html5.min.js"></script>
    <script type="text/javascript">
        $(function() {
            var table = $('#yajradb').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('admin.document')); ?>",
                dom: 'Bfrtip', // Include the buttons plugin with the 'dom' option
                buttons: [{
                        extend: 'excelHtml5',
                        text: 'Export Excel',
                        className: 'btn btn-success',
                        exportOptions: {
                            columns: ':visible' // Export only visible columns
                        }
                    },
                    {
                        extend: 'csvHtml5',
                        text: 'Export CSV',
                        className: 'btn btn-info',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'pdfHtml5',
                        text: 'Export PDF',
                        className: 'btn btn-danger',
                        exportOptions: {
                            columns: ':visible'
                        },
                        orientation: 'landscape', // Set orientation to landscape for PDF
                        pageSize: 'A4' // Set page size for PDF
                    }
                ],
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'title',
                        name: 'title'
                    },
                    {
                        data: 'category_name',
                        name: 'category_name'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: 'download',
                        name: 'download'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ]
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $('.image-popup').on('click', function() {
                var imageUrl = $(this).data('image');
                $('#modalImage').attr('src', imageUrl);
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $('.pdf-popup').on('click', function() {
                var pdfUrl = $(this).data('pdf');
                $('#pdfViewer').attr('src', pdfUrl);
            });

            // Optional: Clear the iframe src when modal is closed
            $('#pdfModal').on('hidden.bs.modal', function() {
                $('#pdfViewer').attr('src', '');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\testenv\resources\views/admin/document.blade.php ENDPATH**/ ?>