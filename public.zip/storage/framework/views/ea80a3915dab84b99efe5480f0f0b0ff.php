<?php $__env->startSection('content'); ?>
<style>
    .file_manager .file .hover {

        top: 18px;
    }

    .float-end {
        float: right !important;
    }
</style>
<!-- Page Loader -->
<div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30"><img
                src="https://greenurjaandenergyefficiencyawards.indianchamber.org/wp-content/themes/icc_green_urja/icc_green_urja/assets/images/logo.svg"
                width="200" height="200" alt="Iconic"></div>
        <p>Please wait...</p>
    </div>
</div>
<div class="container-fluid">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12">
                <h2>Dashboard</h2>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i
                                class="fa fa-dashboard"></i></a></li>
                    <li class="breadcrumb-item">Dashboard</li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ul>
            </div>

        </div>
    </div>

    <!--Add / Edit Form -->
    <div class="row clearfix">
        <div class="col-md-6 col-sm-12">
            <div class="card">
                <div class="header pb-2">

                    <h2><b>Document Category</b></h2>

                </div>
                <div class="body demo-card">

                    <div class="row file_manager">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $encryptedId = encrypt($category->id);
                        ?>
                        <div class="col-md-6 col-sm-12">
                            <div class="card">
                                <div class="file">
                                    <a href="javascript:void(0);"
                                        class="d-flex justify-content-center align-items-center">
                                        <div class="hover ">
                                            <a href="<?php echo e(route('admin.document', ['category_id' => $encryptedId])); ?> "
                                                class="btn btn-icon btn-info text-white btn-sm">
                                                <i class="fa fa-eye"></i>
                                            </a>


                                        </div>
                                        <a href="<?php echo e(route('admin.document', ['category_id' => $encryptedId])); ?> "
                                            class="folder">
                                            <h6 data-toggle="tooltip" data-placement="top"
                                                title="<?php echo e($category->name); ?>"><i
                                                    class="fa fa-folder m-r-10"></i><?php echo Str::limit(strip_tags($category->name), 12); ?></h6>
                                        </a>

                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-12">
            <div class="card">
                <div class="header pb-2">

                    <h2><b>Real Time Business News</b></h2>

                </div>
                <div class="body demo-card">
                    <div class="row">
                        <div class="col-12">
                            <ul class="list-unstyled feeds_widget">
                                <?php $__currentLoopData = $allnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $encryptedId = encrypt($news->id);
                                $formattedDate = \Carbon\Carbon::parse($news->created_at)->format('M d, Y'); // Format the date

                                ?>
                                <a href="<?php echo e(route('admin.newsfulldetails', ['id' => $news->id])); ?> ">
                                    <li class="d-flex">
                                        <div class="feeds-left"><i class="fa fa-newspaper-o text-danger"></i></div>


                                        <div class="feeds-body flex-grow-1">
                                            <h6 class="mb-1 text-danger"><?php echo Str::limit(strip_tags($news->title), 42); ?> &emsp; <small
                                                    class="float-end text-muted small"> <?php echo e($formattedDate); ?></small></h6>
                                        </div>

                                    </li>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="row clearfix">
        <div class="col-md-3 col-sm-12">
            <div class="card">
                <div class="header pb-2">

                    <h2><b>Real Time Business News</b></h2>

                </div>
                <div class="body demo-card">
                    <div class="currency_state d-flex">
                        <div><img src="assets/images/coin/BTC.svg" width="40"></div>
                        <div class="ml-3">
                            <div class="name">Bitcoin</div>
                            <h5 class="mb-0">0.005034</h5>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-md-9 col-sm-12">
            <div class="card">
                <div class="header pb-2">

                    <h2><b>Tender Category</b></h2>

                </div>
                <div class="body demo-card">

                    <div class="row file_manager">
                        <?php $__currentLoopData = $tendercategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $encryptedId = encrypt($category->id);
                        ?>
                        <div class="col-md-4 col-sm-12">
                            <div class="card">
                                <div class="file">
                                    <a href="javascript:void(0);"
                                        class="d-flex justify-content-center align-items-center">
                                        <div class="hover ">
                                            <a href="<?php echo e(route('admin.tender', ['tendercategory_id' => $encryptedId])); ?> "
                                                class="btn btn-icon btn-info text-white btn-sm">
                                                <i class="fa fa-eye"></i>
                                            </a>


                                        </div>
                                        <a href="<?php echo e(route('admin.document', ['category_id' => $encryptedId])); ?> "
                                            class="folder">
                                            <h6 data-toggle="tooltip" data-placement="top"
                                                title="<?php echo e($category->name); ?>"><i
                                                    class="fa fa-folder m-r-10"></i><?php echo Str::limit(strip_tags($category->name), 15); ?></h6>
                                        </a>

                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>


    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('externaljs'); ?>
<script src="<?php echo e(asset('assets/js/index7.js')); ?>"></script>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/testenv/resources/views/admin/admindashboard.blade.php ENDPATH**/ ?>