<?php $__env->startSection('content'); ?>
    <div class="page-heading d-flex flex-wrap justify-content-between align-items-center mt-4 gap-2">
        <h5 class="d-flex align-items-center mb-0 fw-semibold"><?php echo e($create_or_edit); ?> <?php echo e(__('Role')); ?></h5>
    </div>
    <div class="page-content">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col">
                <div class="card rounded-8px border-custom p-3 shadow-custom mb-0 cursor-pointer">
                    <section class="row gx-0 m-0">
                        <div class="col-md-12 col-12 p-md-2 ps-md-0">
                            <div class="row m-0">
                                <form method="post" action="<?php echo e(route('admin.roles.store', $role->id)); ?>"
                                    class="form form-vertical yohrm-ajax-form" data-modal-form="#yohrm-modal">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label for="role-name"><?php echo e(__('Enter Role Name')); ?>*</label>
                                            </div>
                                            <div class="col-md-8 form-group">
                                                <input type="text" id="role-name" class="form-control" name="role"
                                                    placeholder="Enter Role Name" value="<?php echo e($role->name); ?>">
                                            </div>
                                            <div class="col-md-12">
                                                <h5 class="fw-semibold my-4"><?php echo e(__('Role Permissions')); ?></h5>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="email-horizontal"><?php echo e(__('Administrator Access')); ?></label>
                                            </div>

                                            <div class="col-md-8 form-group">
                                                <div class="form-check">
                                                    <div class="checkbox1">
                                                        <input type="checkbox" id="selectAll" class="form-check-input"
                                                            <?php if(!empty($rolePermissions) && count($rolePermissions) == $permissions_count): ?> checked <?php endif; ?>>
                                                        <label for="selectAll"><?php echo e(__('Select All')); ?></label>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-4">
                                                    <label for="email-horizontal">
                                                        <?php echo e($key); ?>

                                                    </label>
                                                </div>

                                                <div class="col-md-8 form-group">
                                                    <div
                                                        class="d-flex justify-content-between align-items-center flex-wrap">

                                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $per_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="form-check">
                                                                <div class="checkbox1">
                                                                    <input type="checkbox" id="del-btn-hiring"
                                                                        name="permission[]" value="<?php echo e($per_name['name']); ?>"
                                                                        class="form-check-input selectAll-inner"
                                                                        <?php if(in_array($per_name['id'], $rolePermissions)): echo 'checked'; endif; ?>>

                                                                    <label for="del-btn-hiring">
                                                                        <?php
                                                                            $name = explode('-', $per_name['name']);
                                                                        ?>

                                                                        <?php echo e(str_replace('_', ' ', end($name))); ?>

                                                                    </label>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-12 d-flex justify-content-end gap-3">
                                                <button type="submit"
                                                    class="btn btn-primary me-1 mb-1"><?php echo e(__('Submit')); ?></button>
                                                <button type="reset"
                                                    class="btn btn-light-secondary me-1 mb-1"><?php echo e(__('Reset')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
            <div class="col-md-2"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\iccadmin\resources\views/admin/roles/roles_create.blade.php ENDPATH**/ ?>