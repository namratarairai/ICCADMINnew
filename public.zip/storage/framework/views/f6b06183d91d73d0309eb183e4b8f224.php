<?php $__env->startSection('content'); ?>
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30"><img
                    src="https://greenurjaandenergyefficiencyawards.indianchamber.org/wp-content/themes/icc_green_urja/icc_green_urja/assets/images/logo.svg"
                    width="200" height="200" alt="Iconic"></div>
            <p>Please wait...</p>
        </div>
    </div>
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h2>Dashboard</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i
                                    class="fa fa-dashboard"></i></a></li>
                        <li class="breadcrumb-item">Dashboard</li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ul>
                </div>

            </div>
        </div>

        <div class="row clearfix">
            <div class="col-lg-4 col-md-4 col-sm-6">
                <div class="card">
                    <div class="body">
                        <div class="currency_state d-flex">
                            <div><img src="<?php echo e(asset('assets/images/coin/BTC.svg')); ?>" width="40" /></div>
                            <div class="ml-3">
                                <div class="name">Manager Editor</div>
                                <h5 class="mb-0">0.005034</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <div class="card">
                    <div class="body">
                        <div class="currency_state d-flex">
                            <div><img src="<?php echo e(asset('assets/images/coin/ETH.svg')); ?>" width="40" /></div>
                            <div class="ml-3">
                                <div class="name">Manager Viewer</div>
                                <h5 class="mb-0">0.001282</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <div class="card">
                    <div class="body">
                        <div class="currency_state d-flex">
                            <div><img src="<?php echo e(asset('assets/images/coin/XRP.svg')); ?>" width="40" /></div>
                            <div class="ml-3">
                                <div class="name">Manage Document</div>
                                <h5 class="mb-0">0.005034</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div> 
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tests\resources\views/admin/superadmindashboard.blade.php ENDPATH**/ ?>