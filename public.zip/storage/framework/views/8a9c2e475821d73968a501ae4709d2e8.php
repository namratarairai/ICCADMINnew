<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h2>News Details List</h2>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news-add')): ?>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="d-flex flex-row-reverse">
                            <div class="page_action">
                                <a href="<?php echo e(asset('assets/excel/exim.xlsx')); ?>" download="" type="button"
                                    class="btn btn-danger">Sample File</a>
                                <a href="<?php echo e(route('admin.addportwiseexportdatashow')); ?>" type="button"
                                    class="btn btn-secondary">Add new</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!---News List -->
        <div class="row clearfix pt-3">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2 class="font-weight-bold">Port Wise Export Data</h2>
                    </div>
                    <div class="body table-responsive">
                        <?php echo e($dataTable->table()); ?>

                    </div>
                </div>
            </div>
        </div>

    </div>

    <!---Delet Model--->
    <div class="modal fade" id="delete_modal" tabindex="-1" aria-labelledby="delete_modal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body text-center pt-4">
                    <h3>Delete Data</h3>
                    <p>Are you sure want to delete?</p>
                    <div class="mb-3">
                        <form action="<?php echo e(route('admin.DeleteData')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="Id" id="delId" />
                            <input type="hidden" name="column" id="delColumn" />
                            <input type="hidden" name="table" id="delTable" />
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancle</button>
                            <button type="submit" class="btn btn-danger">Yes, delete it!</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('externaljs'); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

    <script>
        $(document).on('input', 'input[type="text"]', function() {
            var globalDatatable = window.LaravelDataTables["portwise-table"];
            if (globalDatatable) {
                globalDatatable.settings()[0].ajax.data = function(d) {
                    $(".filter-row input[type='text']").each(function() {
                        var name = $(this).attr('class');
                        var value = $(this).val();
                        if (name) {
                            d[name] = value;
                        }
                    });
                };

                globalDatatable.ajax.reload();
            } else {
                console.error('globalDatatable is not defined.');
            }
        });

        $("body").on('click', '#master', function() {
            var isChecked = $(this).is(':checked');
            $('.select-checkbox').prop('checked', isChecked);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/testenv/resources/views/admin/portwiseexport.blade.php ENDPATH**/ ?>