<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h2>Manage Staff</h2>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="d-flex flex-row-reverse">
                        <div class="page_action">
                            <a href="<?php echo e(route('admin.staff')); ?>" type="button" class="btn btn-secondary">Back
                               </a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Add / Edit Form -->
        <div class="row clearfix">
            <div class="col-md-12">
                <div class="card">
                    <div class="header pb-2">
                        <?php if(!empty($editstaff)): ?>
                            <h2><b>Edit Staff</b></h2>
                            <ul class="header-dropdown">
                                <li class="p-2"><a href="<?php echo e(route('admin.addstaffshow')); ?>"
                                        class="btn btn-primary text-white">Add New</a></li>
                            </ul>
                        <?php else: ?>
                            <h2><b>Add Staff</b></h2>
                        <?php endif; ?>
                    </div>
                    <div class="body demo-card">
                        <form id="addForm" action="<?php echo e(route('admin.addstaff')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e(!empty($editstaff) ? $editstaff->id : ''); ?>">
                            <div class="row clearfix">
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Name <small class="text-danger">*</small></label>
                                        <input type="text" name="name" placeholder="Name *" class="form-control" value="<?php echo e(old('name', $editstaff->name ?? '')); ?>">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Email ID <small class="text-danger">*</small></label>
                                        <input type="email" name="email" placeholder="Email ID *" class="form-control" value="<?php echo e(old('email', $editstaff->email ?? '')); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Password <small class="text-danger">*</small></label>
                                        <input type="password" class="form-control" placeholder="Password *" name="password" id="password"  value="<?php echo e(old('password', $editstaff->original_password ?? '')); ?>">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Mobile Number <small class="text-danger">*</small></label>
                                        <input type="number" name="mobile" placeholder="Mobile Number *" class="form-control" value="<?php echo e(old('mobile', $editstaff->mobile ?? '')); ?>">
                                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label>Select Role</label>
                                        <div class="c_multiselect">
                                            <select name="role_id" class="form-control">
                                                <option value="" disabled selected>Select Role</option>
                                               <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option  value="<?php echo e($each->name); ?>" <?php if(!empty($editstaff) && $editstaff->roles->pluck('name')?->contains($each->name)): echo 'selected'; endif; ?>><?php echo e(ucwords($each->name)); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                               <?php endif; ?>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Address <small class="text-danger">*</small></label>
                                        <textarea name="address" id="permanent_address" cols="30" rows="2" placeholder="Address *" class="form-control no-resize pt-3"><?php echo e(old('address', $editstaff->address ?? '')); ?></textarea>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-lg-3 col-md-3 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label">Subscription Start Date <small class="text-danger">*</small></label>
                                        <input data-provide="datepicker" data-date-autoclose="true" class="form-control" name="subscriptionstartdate" data-date-format="dd/mm/yyyy" placeholder="dd/mm/yyyy" value="<?php echo e(old('subscriptionstartdate', $editstaff->subscriptionstartdate ?? '')); ?>">
                                        <?php $__errorArgs = ['subscriptionstartdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-lg-3 col-md-3 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label">Subscription End Date <small class="text-danger">*</small></label>
                                        <input data-provide="datepicker" data-date-autoclose="true" class="form-control" name="subscriptionenddate" data-date-format="dd/mm/yyyy" placeholder="dd/mm/yyyy" value="<?php echo e(old('subscriptionenddate', $editstaff->subscriptionenddate ?? '')); ?>">
                                        <?php $__errorArgs = ['subscriptionenddate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-6">
                                    <div class="form-group">
                                        <label class="form-label">Export Limit <small class="text-danger">*</small></label>
                                        <input type="number" class="form-control" name="exportlimit" placeholder="Export Limit" value="<?php echo e(old('exportlimit', $editstaff->exportlimit ?? '')); ?>">
                                        <?php $__errorArgs = ['exportlimit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                        <label class="form-label">Download Limit <small class="text-danger">*</small></label>
                                        <input type="number" class="form-control" name="downloadlimit" placeholder="Download Limit" value="<?php echo e(old('downloadlimit', $editstaff->downloadlimit ?? '')); ?>">
                                        <?php $__errorArgs = ['downloadlimit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <button class="mt-3 btn btn-primary form-btn" id="videoBtn" type="submit">SAVE
                                        <i class="fa fa-spin fa-spinner" id="videoSpin" style="display:none;"></i>
                                    </button>
                                    <a class="text-white mt-3 btn btn-danger form-btn" href="<?php echo e(route('admin.staff')); ?>">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('externaljs'); ?>

   <script type="text/javascript">
    $(document).ready(function() {
        // Initialize dropify
        $('.dropify').dropify();

        // Form-validation
        $('#addForm').validate({
            ignore: 'hidden',
            rules: {
                name: {
                    required: true
                },
                email: {
                    required: true,
                    email: true
                },
                password: {
                    required: true
                },
                mobile: {
                    required: true,
                    digits: true
                },
                role_id: {
                    required: true
                },
                address: {
                    required: true
                },
                subscriptionstartdate: {
                    required: true,
                    // date: true
                },
                subscriptionenddate: {
                    required: true,
                    // date: true
                },
                downloadlimit: {
                    required: true,
                    // date: true
                },
                exportlimit: {
                    required: true,
                    // date: true
                }
            },
            messages: {
                name: {
                    required: "Please enter your name"
                },
                email: {
                    required: "Please enter your email",
                    email: "Please enter a valid email address"
                },
                password: {
                    required: "Please enter your password"
                },
                mobile: {
                    required: "Please enter your mobile number",
                    digits: "Please enter a valid mobile number"
                },
                role_id: {
                    required: "Please select a role"
                },
                address: {
                    required: "Please enter your address"
                },
                subscriptionstartdate: {
                    required: "Please select the subscription start date",
                    date: "Please enter a valid date"
                },
                subscriptionenddate: {
                    required: "Please select the subscription end date",
                    date: "Please enter a valid date"
                },

                downloadlimit: {
                    required: "Please enter viewer download limit",
                },
                exportlimit: {
                    required: "Please enter viewer export limit",
                }
            },
            errorElement: 'span',
            errorPlacement: function(error, element) {
                error.addClass('text-danger');
                if (element.attr("name") == "subscriptionstartdate" || element.attr("name") == "subscriptionenddate" || element.attr("name") == "role_id") {
                    error.insertAfter(element.parent());
                } else {
                    error.insertAfter(element);
                }
            },
            highlight: function(element) {
                $(element).addClass('is-invalid mb-1');
            },
            unhighlight: function(element) {
                $(element).removeClass('is-invalid mb-1');
            }
        });

        // Custom validation for Summernote description if needed
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/testenv/resources/views/admin/addstaff.blade.php ENDPATH**/ ?>