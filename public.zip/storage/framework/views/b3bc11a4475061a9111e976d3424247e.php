<?php $__env->startSection('content'); ?>
<style>
    .file_manager .file .hover {

    top: 13px;
}
</style>

    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <h2>Category List</h2>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('documentcategory-add')): ?>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="d-flex flex-row-reverse">
                            <div class="page_action">
                                <a href="<?php echo e(route('admin.addcategoryshow')); ?>" type="button" class="btn btn-secondary">Add new</a>
                            </div>
                            <div class="p-2 d-flex">

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>



        <!--Add / Edit Form -->
        

        <!---Category List -->
        


        <div class="row clearfix file_manager">

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $encryptedId = encrypt($category->id);
                ?>
                <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="card">
                        <div class="file">
                            <a href="javascript:void(0);" class="d-flex justify-content-center align-items-center">
                                <div class="hover ">
                                    <a href="<?php echo e(route('admin.document', ['category_id' => $encryptedId])); ?> "
                                        class="btn btn-icon btn-info text-white btn-sm">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                    <a href="javascript:void(0)"
                                        onclick="deleteData('id', '<?php echo e($category->id); ?>', '<?php echo e($tablename); ?>')"
                                        class="btn btn-icon btn-danger text-white btn-sm ">
                                        <i class="fa fa-trash"></i>
                                    </a>

                                    <a href="<?php echo e(route('admin.editcategory', ['id' => $encryptedId])); ?>"
                                        class="btn btn-icon btn-secondary text-white btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                </div>
                                <a href="<?php echo e(route('admin.document', ['category_id' => $encryptedId])); ?> " class="folder">
                                    <h6 data-toggle="tooltip" data-placement="top" title="<?php echo e($category->name); ?>"><i
                                            class="fa fa-folder m-r-10"></i><?php echo Str::limit(strip_tags($category->name), 16); ?></h6>
                                </a>

                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>

    </div>

    <!---Delet Model--->
    <div class="modal fade" id="delete_modal" tabindex="-1" aria-labelledby="delete_modal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body text-center pt-4">
                    <h3>Delete Data</h3>
                    <p>Are you sure want to delete?</p>
                    <div class="mb-3">
                        <form action="<?php echo e(route('admin.deletecategory')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="Id" id="delId" />
                            <input type="hidden" name="column" id="delColumn" />
                            <input type="hidden" name="table" id="delTable" />
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
                            <button type="submit" class="btn btn-danger">Yes, delete it!</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('externaljs'); ?>
    <script>
        $(document).ready(function() {
            $('#AddForm').validate({
                ignore: ":hidden:not('.validate-hidden')",
                rules: {
                    role_name: {
                        required: true,
                        remote: {
                            url: "<?php echo e(route('admin.checkCategoryName')); ?>",
                            type: "post",
                            data: {
                                role_name: function() {
                                    return $("input[name='name']").val();
                                },
                                id: function() {
                                    return $("input[name='id']")
                                .val(); // Assuming you have an input field for the category ID in your form
                                },
                                _token: "<?php echo e(csrf_token()); ?>"
                            },
                            dataFilter: function(response) {
                                var data = JSON.parse(response);
                                if (data.isDuplicate) {
                                    return JSON.stringify("Category name already exists");
                                } else {
                                    return true;
                                }
                            }
                        }
                    },
                },
                messages: {
                    name: {
                        required: "Please enter the category name",
                        remote: "Category name already exists"
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('text-danger');
                    if (element.attr("name") == "nametype") {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                },
                highlight: function(element) {
                    $(element).addClass('is-invalid mb-1');
                },
                unhighlight: function(element) {
                    $(element).removeClass('is-invalid mb-1');
                }
            });

        });
    </script>

    <script type="text/javascript">
        $(function() {

            var table = $('#yajradb').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('admin.category')); ?>",
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tests\resources\views/admin/category.blade.php ENDPATH**/ ?>